library(dplyr)
library(sqldf)
library(ggplot2)
library(plotly)
library(rJava)
library(Rserve)



## Interactive Chart
f1 <- function(){
  animals <- read.csv("animals.csv")
  ani.sex.result0 <- as.data.frame(table(animals$성별));
 # View(ani.sex.result0)
  png("sex.png",width=600,height=500);
  a1<-ggplot(data=ani.sex.result0,aes(x=Var1,y=Freq)) + geom_col();
  dev.off();
 
  ggplotly(a1);
  
  return(ani.sex.result0);
}

f2 <- function(){
  tmp0 <- table(animals$품종)
  tmp1 <- as.data.frame(tmp0)
  colnames(tmp1) <- c("품종","CNT")
  tmp2 <- (tmp1[tmp1$CNT <= 5,])
  ani.rare.result0 <- (tmp2[substr(tmp2$품종,1,6) == "[기타축종]",])
  
  class(ani.rare.result0)
  ggplot(data=ani.rare.result0,aes(x=품종,y=CNT)) +
    geom_col()
  return(ani.rare.result0);
}

## Image Chart (png)