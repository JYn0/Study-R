library(dplyr)
library(sqldf)
library(ggplot2)
library(plotly)
library(rJava)
library(Rserve)
animals <- read.csv("animals.csv")


## Interactive Chart
f1 <- function(){

  ##hive 
  
  library(RJDBC);
  library(DBI);
  library(rJava);
  hive_lib <- 'c:\\lib';
  .jinit();
  .jaddClassPath(dir(hive_lib,full.names = T));
  .jclassPath();
  
  drv=JDBC(driverClass='org.apache.hive.jdbc.HiveDriver',
           'hive-jdbc-1.0.1.jar');
  conn=dbConnect(drv,"jdbc:hive2://70.12.114.211:10000",
                 "root","111111");
  
  user=dbGetQuery(conn,"select hdi.country,hdi.hdi from hdi limit 10");
  a100=dbGetTables("animals")
  dbDisconnect(conn);
  
  
  
  ani.sex.result0 <- as.data.frame(table(animals$sex));
  # View(ani.sex.result0)
  
  
  png("sex.png",width=600,height=500);
  a1 <- ggplot(data=ani.sex.result0,aes(x=Var1,y=Freq)) + geom_col();
  dev.off();
  #interactive chart 
  a2 <- ggplotly(a1);
  
  #interactive chart saved as html
  htmlwidgets::saveWidget(as_widget(a2), "sex.html" )
  
  return(ani.sex.result0);
}

f2 <- function(){
  animals <- read.csv("animals.csv")
  tmp0 <- table(animals$species)
  tmp1 <- as.data.frame(tmp0)
  colnames(tmp1) <- c("species","CNT")
  tmp2 <- (tmp1[tmp1$CNT <= 5,])
  ani.rare.result0 <- tmp2[substr(tmp2$species,1,7) == "[other]",]
 

  
  class(ani.rare.result0)
  b1 <- ggplot(data=ani.rare.result0,aes(x=species,y=CNT)) + geom_col()
  
  b2 <- ggplotly(b1);
  htmlwidgets::saveWidget(as_widget(b2), "rare.html" )
  
  
  return(ani.rare.result0);
}

f3 <- function(){
  tmp3 <- animals[animals$status %in% "euthanasia",]
  tmp4 <- table(tmp3$species)
  tmp4 <- as.data.frame(tmp4)
  colnames(tmp4) <- c("species","CNT")
  ani.status.result0 <- tmp4[tmp4$CNT != 0,]
  
  ani.status.result0 <- ani.status.result0[order(ani.status.result0$CNT,decreasing = T),]
  head(ani.status.result0,5)
  ggplot(data=head(ani.status.result0,5),aes(x=species,y=CNT)) +
    geom_col()
  
  c1<-ggplot(data=head(ani.status.result0,5),aes(x=species,y=CNT)) + geom_col()
  c2 <- ggplotly(c1);
  htmlwidgets::saveWidget(as_widget(c2), "status.html" )
  return(ani.status.result0);
}

f4 <-function(){
  tmp5 <- (animals[substr(animals$status,1,3) == "END",])
  tmp6 <- table(tmp5$status)
  tmp7 <- sum(tmp6)
  tmp8 <- as.data.frame(tmp6)
  colnames(tmp8) <- c("status","CNT")
  tmp8$p <- tmp8$CNT * 100 / tmp7
  ani.endstatus.result0 <- tmp8[tmp8$status!="shelter",c(1,3)]

  lbls0 <- ani.endstatus.result0$status
  values0 <- ani.endstatus.result0$p
  
  pie(as.numeric(values0), labels = lbls0, main=" Ended Abandont Animal Status ")
  d1<-ggplot(data=head(ani.endstatus.result0,5),aes(x=status,y=p)) + geom_col()
  d2<- ggplotly(d1)
  htmlwidgets::saveWidget(as_widget(d2), "endstatus.html" )

  return(ani.endstatus.result0)
}

f5 <- function(){
  ani.species.result <- sqldf('
                        select "species", count(*) as num
                        from animals
                        group by "species"
                        having count(*) > 150
                      ')
  
  ani.etc.result <- sqldf('
                        select count(*) as num
                        from animals
                        group by "species"
                        having count(*) <= 150
                      ')
  
  ani.etc.count <- sum(ani.etc.result$num)
  
  ani.species.result$species <- as.character(ani.species.result$species)
  
  ani.species.result <- rbind(ani.species.result, c("other", as.numeric(ani.etc.count)))
  
  e1<-ggplot(data=head(ani.species.result,5),aes(x=species,y=num)) + geom_col()
  e2<- ggplotly(e1)
  htmlwidgets::saveWidget(as_widget(e2), "f2(0species.html" )
  
  lbls <- ani.species.result$species
  values <- ani.species.result$num
  
  pie(as.numeric(values), labels = lbls, main="Status of Abandont Animal per species")
  
  return(ani.species.result)
}


