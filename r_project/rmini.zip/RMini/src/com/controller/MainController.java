package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MainController {
	@RequestMapping("/index.mc")
	public ModelAndView index(ModelAndView mv) {
		mv.setViewName("index");
		
		return mv;
	}
	
	@RequestMapping("/getDataf1.mc")
	public ModelAndView getDataF1(HttpServletRequest request, ModelAndView mv) throws Exception {
		RConnection rc = new RConnection("70.12.114.210");
		rc.setStringEncoding("utf8");
		System.out.println("Try to Connect...");
		rc.eval("source('/home/centos/R/rmini/r01.R', encoding = 'UTF-8')");
		String path = request.getSession().getServletContext().getRealPath("");
		REXP rx = rc.eval("f1()");
		
		RList rlist = rx.asList();
		String var1[] = rlist.at("Var1").asStrings();
		int freq[] = rlist.at("Freq").asIntegers();
		
		JSONArray ja = new JSONArray();
		
		for (int i = 0 ; i < var1.length; i++) {
			JSONObject jo = new JSONObject();
			
			jo.put("name", var1[i]);
			jo.put("y", freq[i]);
			
			ja.add(jo);
		}
		
		System.out.println(ja.toJSONString());
		System.out.println("Connection OK");
		
		mv.addObject("datas", ja);
		mv.addObject("center", "f1");
		mv.setViewName("index");
		
		return mv;
	}	
	
	@RequestMapping("/getDataf3.mc")
	public ModelAndView getDataF3(HttpServletRequest request, ModelAndView mv) throws Exception {
		RConnection rc = new RConnection("70.12.114.210");
		rc.setStringEncoding("utf8");
		System.out.println("Try to Connect...");
		rc.eval("source('/home/centos/R/rmini/r01.R', encoding = 'UTF-8')");
		String path = request.getSession().getServletContext().getRealPath("");
		REXP rx = rc.eval("f3()");
		
		RList rlist = rx.asList();
		String species[] = rlist.at("species").asStrings();
		int cnt[] = rlist.at("CNT").asIntegers();
		
		JSONArray ja = new JSONArray();
		
		for(int i = 0 ; i < species.length ; i++) {
			JSONObject jo = new JSONObject();
			
			jo.put("name", species[i]);
			jo.put("y", cnt[i]);
			
			ja.add(jo);
		}
		
		System.out.println(ja.toJSONString());
		System.out.println("Connection OK");
		
		mv.setViewName("index");
		mv.addObject("center", "f3");
		mv.addObject("datas",ja);
		
		return mv;
	}

	
	@RequestMapping("/getDataf4.mc")
	public ModelAndView getDataF4(HttpServletRequest request, ModelAndView mv) throws Exception {
		RConnection rc = new RConnection("70.12.114.210");
		rc.setStringEncoding("utf8");
		System.out.println("Try to Connect...");
		rc.eval("source('/home/centos/R/rmini/r01.R', encoding = 'UTF-8')");
		String path = request.getSession().getServletContext().getRealPath("");
		REXP rx = rc.eval("f4('" + path + "')");
		
		RList rlist = rx.asList();
		String status[] = rlist.at("status").asStrings();
		double ps[] = rlist.at("p").asDoubles();
		
		JSONArray ja = new JSONArray();
		
		for(int i = 0 ; i < status.length ; i++) {
			JSONObject jo = new JSONObject();
			
			jo.put("name", status[i]);
			jo.put("y", ps[i]);
			
			ja.add(jo);
		}
		
		System.out.println(ja.toJSONString());
		System.out.println("Connection OK");

		mv.setViewName("index");
		mv.addObject("center", "f4");
		mv.addObject("datas",ja);
		
		return mv;
	}
	
	@RequestMapping("/getDataf5.mc")
	public ModelAndView getDataF5(HttpServletRequest request, ModelAndView mv) throws Exception {
		RConnection rc = new RConnection("70.12.114.210");
		rc.setStringEncoding("utf8");
		System.out.println("Try to Connect...");
		rc.eval("source('/home/centos/R/rmini/r01.R', encoding = 'UTF-8')");
		String path = request.getSession().getServletContext().getRealPath("");
		REXP rx = rc.eval("f5('" + path + "')");
		
		RList rlist = rx.asList();
		String species[] = rlist.at("species").asStrings();
		String numsString[] = rlist.at("num").asStrings();
		int nums[] = new int[numsString.length];
		
		for (int i = 0 ; i < nums.length ; i++) {
			nums[i] = Integer.parseInt(numsString[i]);
		}

		JSONArray ja = new JSONArray();
		
		for(int i = 0 ; i < species.length ; i++) {
			JSONObject jo = new JSONObject();
			
			jo.put("name", species[i]);
			jo.put("y", nums[i]);
			
			ja.add(jo);
		}
		
		System.out.println(ja.toJSONString());
		System.out.println("Connection OK");

		mv.setViewName("index");
		mv.addObject("center", "f5");
		mv.addObject("datas",ja);
				
		return mv;
	}
	

	
//	@RequestMapping("/getDataf2.mc")
//	public ModelAndView getDataF2(HttpServletRequest request, ModelAndView mv) throws Exception {
//		RConnection rc = new RConnection("70.12.114.210");
//		rc.setStringEncoding("utf8");
//		System.out.println("Try to Connect...");
//		rc.eval("source('C:/rstudio/rmini/r01.R', encoding = 'UTF-8')");
//		REXP rx = rc.eval("f2()");
//		
//		RList rlist = rx.asList();
//		String species[] = rlist.at("species").asStrings();
//		int cnt[] = rlist.at("CNT").asIntegers();
//		
//		JSONArray ja = new JSONArray();
//		
//		for(int i = 0 ; i < species.length ; i++) {
//			JSONObject jo = new JSONObject();
//			
//			jo.put("species", species[i]);
//			jo.put("CNT", cnt[i]);
//			
//			ja.add(jo);
//		}
//		
//		mv.setViewName("index");
//		mv.addObject("center", "f2");
//		mv.addObject("datas",ja);
//		
//		System.out.println(ja.toJSONString());
//		System.out.println("Connection OK");
//		
//		return mv;
//	}
}
