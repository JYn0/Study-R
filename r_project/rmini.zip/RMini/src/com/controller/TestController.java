package com.controller;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {
	@RequestMapping("/test.mc")
	public void test(HttpServletRequest request) {
		String pathSet = request.getSession().getServletContext().getRealPath("");
		System.out.println(pathSet);	
	}
}
